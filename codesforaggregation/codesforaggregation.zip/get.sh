curl -XPOST 10.10.10.1:9200/streamingevent*/_search?pretty -H 'Content-type: application/json' -d @$1
